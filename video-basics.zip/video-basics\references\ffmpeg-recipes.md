# ffmpeg recipes

Swap in the real file names. Each recipe writes a new file and never touches the input.

Export flags used below (call them `$EXPORT`):
`-c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart`

## Look at a video

```bash
# length, size, fps
ffprobe -v error -show_entries format=duration:stream=codec_type,width,height,r_frame_rate -of compact "in.mp4"

# contact sheet: one frame every 2 s, 4x4 grid, so you can see the whole video in one picture
ffmpeg -i "in.mp4" -vf "fps=1/2,scale=320:-1,tile=4x4" -frames:v 1 sheet.png

# one frame at 12.5 s
ffmpeg -ss 12.5 -i "in.mp4" -frames:v 1 frame.png

# find scene cuts (prints a timestamp for each cut)
ffmpeg -i "in.mp4" -vf "select='gt(scene,0.3)',showinfo" -f null - 2>&1 | grep pts_time
```

## Cut and join

```bash
# trim 0:05 to 0:15 (re-encoded, so the cut is frame-accurate)
ffmpeg -ss 00:00:05 -to 00:00:15 -i "in.mp4" $EXPORT out.mp4

# join clips that share codec, size and fps: list.txt has lines like  file 'a.mp4'
ffmpeg -f concat -safe 0 -i list.txt -c copy joined.mp4

# speed up 1.5x (video and audio)
ffmpeg -i "in.mp4" -filter_complex "[0:v]setpts=PTS/1.5[v];[0:a]atempo=1.5[a]" -map "[v]" -map "[a]" $EXPORT fast.mp4

# fade in 0.5 s at the start, fade out over the last 0.5 s of a 30 s clip
ffmpeg -i "in.mp4" -vf "fade=t=in:st=0:d=0.5,fade=t=out:st=29.5:d=0.5" -af "afade=t=in:d=0.5,afade=t=out:st=29.5:d=0.5" $EXPORT faded.mp4
```

## Resize

```bash
# horizontal -> vertical 1080x1920, with a blurred copy of the video filling the background
ffmpeg -i "in.mp4" -filter_complex "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=20:5[bg];[0:v]scale=1080:-2[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2" $EXPORT vertical.mp4

# crop the centre to vertical (no blur, fills the screen)
ffmpeg -i "in.mp4" -vf "crop=ih*9/16:ih,scale=1080:1920" $EXPORT vertical_crop.mp4
```

## Text and captions

```bash
# burn in subtitles from an .srt
ffmpeg -i "in.mp4" -vf "subtitles=subs.srt:force_style='FontName=Arial,FontSize=16,Outline=2,Alignment=2,MarginV=60'" $EXPORT captioned.mp4

# simple text on screen from 1 s to 4 s
ffmpeg -i "in.mp4" -vf "drawtext=text='Hello':fontsize=72:fontcolor=white:borderw=4:x=(w-text_w)/2:y=h*0.15:enable='between(t,1,4)'" $EXPORT text.mp4
```

On Windows, `drawtext` may need `fontfile='C\:/Windows/Fonts/arial.ttf'`. The colon after the drive letter must be escaped.

## Audio

```bash
# pull the audio out
ffmpeg -i "in.mp4" -vn -c:a libmp3lame -q:a 2 audio.mp3

# even out loudness (YouTube-friendly -14 LUFS)
ffmpeg -i "in.mp4" -c:v copy -af "loudnorm=I=-14:TP=-1.5:LRA=11" -c:a aac -b:a 192k loud.mp4

# remove silences longer than 0.4 s from a voice recording (audio only)
ffmpeg -i "voice.wav" -af "silenceremove=start_periods=1:stop_periods=-1:stop_duration=0.4:stop_threshold=-40dB" voice_tight.wav

# music under a voice, music ducks when the voice talks
ffmpeg -i "voice.wav" -i "music.mp3" -filter_complex "[0:a]asplit=2[v1][v2];[1:a]volume=0.3[m];[m][v1]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=400[d];[v2][d]amix=inputs=2:duration=first:normalize=0[a]" -map "[a]" mix.wav

# replace a video's audio with a new track
ffmpeg -i "in.mp4" -i "mix.wav" -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest final.mp4
```

Tune the silence threshold: raise it to -35dB if background noise stops cuts, or lower it to -45dB if quiet words get cut.
