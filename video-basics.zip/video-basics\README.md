# video-basics: a free Claude Code skill

Edit and make videos by talking to Claude Code:
- **ffmpeg** handles footage: trim, join, go vertical, add captions, fix audio, cut silences, add music.
- **Remotion** and **three.js** make videos from code: animated titles, motion graphics, simple 3D.

## Install

1. Install [ffmpeg](https://ffmpeg.org/download.html) and [Node.js](https://nodejs.org) (18 or newer).
2. Copy the `video-basics` folder into your skills folder:
   - **Windows:** `C:\Users\<you>\.claude\skills\video-basics\`
   - **Mac/Linux:** `~/.claude/skills/video-basics/`
3. Open Claude Code and ask for something like:
   - "Make clip.mp4 vertical for Shorts with a blurred background"
   - "Cut the silences out of voice.wav"
   - "Make a 5 second Remotion intro with my channel name popping in"
   - "Make a spinning 3D logo in Remotion"

## What's inside

- `SKILL.md`: how Claude approaches video jobs (check first, preview, then render).
- `references/ffmpeg-recipes.md`: ready-made ffmpeg commands.
- `references/remotion-three.md`: Remotion and three.js starter code.
