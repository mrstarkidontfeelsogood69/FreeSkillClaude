# Remotion + three.js basics

Remotion turns React components into video. Each frame is your component rendered at `useCurrentFrame()`.

**Licence:** Remotion is free for individuals and small teams. Companies above a certain size need a paid licence (see remotion.dev/license).

## Start a project

```bash
npx create-video@latest      # pick a template (Blank or Hello World is fine)
cd my-video
npm run dev                  # opens Remotion Studio in the browser to preview
```

## The core pieces

```tsx
import {AbsoluteFill, Sequence, useCurrentFrame, useVideoConfig, interpolate, spring, Audio, OffthreadVideo, staticFile} from 'remotion';

export const Title: React.FC<{text: string}> = ({text}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const pop = spring({frame, fps, config: {damping: 12}});              // 0 -> 1 with a little bounce
  const fadeOut = interpolate(frame, [60, 75], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', backgroundColor: '#0d0d12'}}>
      <h1 style={{color: 'white', fontSize: 120, fontFamily: 'sans-serif', transform: `scale(${pop})`, opacity: fadeOut}}>
        {text}
      </h1>
    </AbsoluteFill>
  );
};

// A video made of parts: <Sequence> shifts time so each part starts at its own frame 0
export const Main: React.FC = () => (
  <AbsoluteFill>
    <Sequence durationInFrames={90}><Title text="Part one" /></Sequence>
    <Sequence from={90} durationInFrames={90}><Title text="Part two" /></Sequence>
    <Audio src={staticFile('music.mp3')} volume={0.3} />
  </AbsoluteFill>
);
```

- Put media files in `public/` and load them with `staticFile('name.mp4')`.
- Use `<OffthreadVideo src={staticFile('clip.mp4')} />` for footage.
- **Animate only from `frame`.** Never use `Date.now()`, `setTimeout` or CSS animations. They don't line up with the render.
- `interpolate` maps the frame to any value (position, opacity, rotation). Always clamp it.
- `spring` gives natural-feeling motion for pop-ins.

Register each video in `src/Root.tsx`:

```tsx
<Composition id="Main" component={Main} durationInFrames={180} fps={30} width={1080} height={1920} />
```

## 3D with three.js

```bash
npx remotion add @remotion/three     # installs @remotion/three, three and @react-three/fiber at matching versions
```

```tsx
import {AbsoluteFill, useCurrentFrame, useVideoConfig, spring} from 'remotion';
import {ThreeCanvas} from '@remotion/three';

export const SpinningCube: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height, fps} = useVideoConfig();
  const pop = spring({frame, fps, config: {damping: 12}});
  return (
    <AbsoluteFill style={{backgroundColor: '#111'}}>
      <ThreeCanvas width={width} height={height} camera={{position: [0, 0, 5], fov: 50}}>
        <ambientLight intensity={0.5} />
        <directionalLight position={[3, 4, 5]} intensity={1.2} />
        <mesh rotation={[frame * 0.02, frame * 0.03, 0]} scale={pop}>
          <boxGeometry args={[1.5, 1.5, 1.5]} />
          <meshStandardMaterial color="#7c5cff" />
        </mesh>
      </ThreeCanvas>
    </AbsoluteFill>
  );
};
```

- Drive every movement from `useCurrentFrame()`, **not** react-three-fiber's `useFrame`. Otherwise the render won't match the preview.
- No lights means a black scene. Start with one ambient light and one directional light.
- For a 3D model, put a `.glb` in `public/` and load it with `useGLTF(staticFile('model.glb'))` from `@react-three/drei` (`npm i @react-three/drei`).

## Render

```bash
npx remotion still Main --frame=45 preview.png          # check one frame first
npx remotion render Main out/video.mp4                  # full render (H.264 MP4)
npx remotion render Main out/video.mp4 --crf=18         # higher quality
```
