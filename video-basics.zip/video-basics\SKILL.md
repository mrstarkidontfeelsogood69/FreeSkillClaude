---
name: video-basics
description: Edit and make videos with code. Use when the user wants to trim, cut, join, resize, caption, speed up, clean up audio or export a video (ffmpeg), or wants to build an animated video, motion graphics, text animation or simple 3D scene from code (Remotion + three.js).
---

# Video basics (ffmpeg + Remotion + three.js)

You are helping someone edit or make videos with code. Two tools cover almost everything:

- **ffmpeg** for editing existing footage: trimming, joining, resizing, captions, audio, exporting.
- **Remotion** (React) for making videos from code: titles, motion graphics, animated text and, through `@remotion/three`, 3D scenes made with three.js.

## 1. Before anything

1. Ask what the video is for (YouTube, Shorts/TikTok/Reels), and how long it should be, if they didn't say.
2. Check the tools they have:
   - `ffmpeg -version`
   - `node -v` (Remotion needs Node 18 or newer)
   If something is missing, tell them how to install it and **ask before installing anything**.
3. Look at the input before editing it:
   - `ffprobe -v error -show_entries format=duration:stream=codec_type,width,height,r_frame_rate -of compact "input.mp4"`

## 2. Ground rules

- **Never overwrite the original file.** Write to a new name (`_edit`, `_v2` and so on).
- **Preview before the full render.**
  - For long ffmpeg jobs, test on 5 seconds first (`-t 5`).
  - In Remotion, render a still (`npx remotion still`) before the whole video.
- **Pick the size for the platform:**
  - 1920x1080 for YouTube.
  - 1080x1920 for Shorts, TikTok and Reels.
- **Export settings that upload cleanly everywhere:**
  `-c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart`
- Quote every path (spaces break commands). On Windows, prefer forward slashes inside ffmpeg filters.
- If they use music or clips they didn't make, remind them once about copyright before they upload.

## 3. Which tool?

| They want to... | Use |
|---|---|
| Cut, trim, join clips, change speed | ffmpeg |
| Turn a horizontal video vertical | ffmpeg (blurred background recipe) |
| Add subtitles from an .srt | ffmpeg |
| Fix loud/quiet audio, cut silences, add music under a voice | ffmpeg |
| Titles, animated text, lower thirds, intros | Remotion |
| Motion graphics, animated charts, a whole video from code | Remotion |
| A spinning logo, 3D object, simple 3D scene | Remotion + `@remotion/three` |

Recipes:
- ffmpeg: `references/ffmpeg-recipes.md`
- Remotion and three.js: `references/remotion-three.md`

Read the one you need before writing commands.

## 4. Workflow

1. Make sure you understand the goal and have looked at the input (section 1).
2. Write the command or code, and say in one line what it does.
3. Run a short preview (5 seconds or one still) and check it: look at the still, or ffprobe the result.
4. Run the full render.
5. Report what was made: file path, length, resolution. Mention anything that didn't work.

## 5. When something breaks

- **"No such filter" / "Unknown encoder":** their ffmpeg build is old or minimal. Show the error and suggest a full build.
- **Audio out of sync after cutting:** re-encode instead of `-c copy`. Stream copy can only cut on keyframes.
- **Concat fails or glitches:** the clips have different codecs, sizes or frame rates. Re-encode them all to the same settings first.
- **Remotion render is slow:** lower `--concurrency` if the computer struggles, or raise it if the CPU has spare cores.
- **Three.js scene is black:** add lights (`ambientLight` + `directionalLight`), and check that the camera isn't inside the object.
